README for cluster_size_script.ijm for Zhai, et al., �Statistics of correlated percolation in a bacterial community�,
PLoS Computational Biology (2019).

This README was written by Joseph W. Larkin (jwlarkin@bu.edu) on 11/20/2019.

This folder contains a file with a script for extracting the data plotted in Fig. 6B in Zhai et al., as well as the
processed image data from which the curves were generated.

To extract cluster sizes, open the binarized cell and cluster images for a given electrical pulse in Fiji. These
images are contained in, respectively, the /images/cells/ and /images/clusters/ folders in this folder. A given
pulse will have filenames such as WT_cell_*.tif and WT_cluster_*.tif, where * is a number that should be the same for
the two files. Through Fiji run the macro cluster_size_script.ijm (either via Plugins > Macros > Run... and select
the file or open the file in the Fiji macro editor and click "Run"). The script will prompt the user in a pull down
window to identify the cell and cluster images. Select the appropriate images and click OK. The script will then run.
It will create multiple dummy images for analysis that will be closed upon script completion. This should take a
couple minutes per set. After the script finishes, the user will be notified via standard output and a file containing
cluster sizes will be saved. The location of this file can be edited in line 158 of cluster_size_script.ijm. This script
is not very robust. Sorry about that!